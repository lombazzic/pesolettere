using System;
using System.Collections.Generic;

public static class PesoLettere
{
    
    public static int Pesa(string input)
    {
        int lunghezza = input.Length;
        int p=0;
        int j;
        string uno ="AEIOULNRSTaeioulnrst";
        string due ="DGdg";
        string tre ="BCMPbcmp";
        string qtt ="FHVWYfhvwy";
        string cnq ="Kk";
        string ott ="JXjx";
        string dic ="QZqz";
        for(j=0; j<lunghezza; j++)
        {
            for(int i=0; i<uno.Length;i++)
            {
                if(input[j]==uno[i])
                {
                    p=p+1;
                }
            }
            for(int i=0; i<due.Length;i++)
            {
                if(input[j]==due[i])
                {
                    p=p+2;
                }
            }
            for(int i=0; i<tre.Length;i++)
            {
                if(input[j]==tre[i])
                {
                    p=p+3;
                }
            }
            for(int i=0; i<qtt.Length;i++)
            {
                if(input[j]==qtt[i])
                {
                    p=p+4;
                }
            }
            for(int i=0; i<cnq.Length;i++)
            {
                if(input[j]==cnq[i])
                {
                    p=p+5;
                }
            } 
            for(int i=0; i<ott.Length;i++)
            {
                   if(input[j]==ott[i])
                {
                    p=p+8;
                }
            }
            for(int i=0; i<dic.Length;i++)
            {
                if(input[j]==dic[i])
                {
                    p=p+10;
                }
            }
           
           
        }
        return p;
        
    }
}